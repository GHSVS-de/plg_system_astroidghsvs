These are just examples for a base scaffold of the "system". Not ready to use.
